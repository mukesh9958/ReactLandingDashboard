# Responsive Website Built with React and Framer Motion with Scrolling.

## [Watch it on youtube](https://youtu.be/bKhfUrUgWng)

Don't forget to join the channel for more videos like this.
[Kishan Sheth](https://www.youtube.com/c/kishansheth21?sub_confirmation=1)

Support me with a [coffee](https://www.buymeacoffee.com/koolkishansheth)
